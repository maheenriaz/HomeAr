import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';
import Container from './src/index';

export default class App extends React.Component{
  render(){
    return (
     <Container />
    );
  }
};


